from pathlib import Path
import sys, json, ctypes, hashlib, unittest
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from scratch.nnue_full_suite_attestation import ExclusiveSuiteLease, ProductionOpenGuard, execute_suite, inventory_sha256, source_inventory_paths, test_inventory_paths
from scratch.nnue_scaling_final_audit import DEFAULT_WORK_DIR
ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(),0x4000)
out=ROOT/'build/native_endgame_c2/verification'
out.mkdir(exist_ok=True)
guard=ProductionOpenGuard(DEFAULT_WORK_DIR)
guard.forbidden_roots.add((ROOT/'build/nnue_sprt_6t_vs_12t').resolve())
sys.addaudithook(guard.hook)
with ExclusiveSuiteLease(ROOT) as lease:
    sources=source_inventory_paths() + [ROOT/'tests/native_endgame_boundaries.c', ROOT/'tools/build_endgame_c2.ps1']
    before=inventory_sha256(sources)
    tests_before=inventory_sha256(test_inventory_paths())
    suite=unittest.defaultTestLoader.discover(str(ROOT/'tests'))
    discovered=suite.countTestCases()
    print('Discovered',discovered,flush=True)
    result,log,elapsed=execute_suite(suite,checkpoint=lease.checkpoint)
    (out/'full_suite.log').write_text(log,encoding='utf-8')
    report=dict(tests_discovered=discovered,tests_run=result.testsRun,failures=len(result.failures),errors=len(result.errors),skipped=len(result.skipped),elapsed_seconds=elapsed,source_inventory_sha256=before,test_inventory_sha256=tests_before,inventories_unchanged=before==inventory_sha256(sources) and tests_before==inventory_sha256(test_inventory_paths()),protected_open_attempts=len(guard.triggered),candidate_sha256=hashlib.sha256((ROOT/'build/native_endgame_c2/makhos_endgame_search.dll').read_bytes()).hexdigest())
    report['status']='PASS' if result.wasSuccessful() and report['inventories_unchanged'] and not guard.triggered else 'FAIL'
    (out/'full_suite.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(report),flush=True)
    sys.exit(0 if report['status']=='PASS' else 1)
