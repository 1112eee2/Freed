"""Isolated verification for the Phase 1A telemetry change; no SPRT resume."""
from contextlib import ExitStack
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import types
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from benchmarks.endgame_latency import cases, result_signature
from makhos import server
from makhos.native import NativeSearch
from makhos.ranked_tablebase import RankedTablebase
from makhos.search import Engine
from scratch.nnue_full_suite_attestation import (
    ExclusiveSuiteLease, ProductionOpenGuard, execute_suite,
    inventory_sha256, source_inventory_paths, test_inventory_paths,
)
from scratch.nnue_scaling_final_audit import DEFAULT_WORK_DIR
from tests.test_server import DummyHandler

out = ROOT / "build/endgame_latency_phase1_verification_final"
out.mkdir(exist_ok=False)
guard = ProductionOpenGuard(DEFAULT_WORK_DIR)
guard.forbidden_roots.add((ROOT / "build/nnue_sprt_6t_vs_12t").resolve())
sys.addaudithook(guard.hook)
with ExclusiveSuiteLease(ROOT) as lease:
    source_paths = source_inventory_paths() + list((ROOT / "benchmarks").glob("*.py"))
    source_before = inventory_sha256(source_paths)
    tests_before = inventory_sha256(test_inventory_paths())
    baseline = subprocess.check_output(["git", "show", "ec26c5e:makhos/server.py"], cwd=ROOT)
    (out / "baseline_server.py").write_bytes(baseline)
    control = types.ModuleType("makhos._latency_control_server")
    control.__file__ = str(ROOT / "makhos/server.py")
    control.__package__ = "makhos"
    exec(compile(baseline, str(out / "baseline_server.py"), "exec"), control.__dict__)
    parity = []
    with ExitStack() as resources:
        ranked = [resources.enter_context(RankedTablebase(ROOT / f"build/tb{n}_np80.compact.bin"))
                  for n in (4, 5, 6)]
        release = server.load_release(server.DEFAULT_POINTER)
        native = resources.enter_context(NativeSearch(release["native_library"], hash_power=16,
                                                       nnue_model=release["nnue_model"]))
        engine = Engine(ranked_tablebases=ranked, native_search=native, exact_piece_limit=0)
        for case in cases()[1:]:
            for mode in ("best", "win"):
                for depth in (1, 2, 3):
                    lease.checkpoint("before baseline parity case")
                    signatures = []
                    for module in (control, server):
                        engine.clear()
                        handler = DummyHandler({})
                        with patch.object(module, "get_default_engine", return_value=engine):
                            module.EngineRequestHandler.handle_bestmove(handler, {
                                **case, "mode": mode, "depth": depth,
                                "time_sec": 30, "use_full_time": False,
                            })
                        assert handler.response_status == 200
                        signatures.append(result_signature(json.loads(handler.wfile.bytes)))
                    assert signatures[0] == signatures[1], (case["id"], mode, depth, signatures)
                    parity.append({"case": case["id"], "mode": mode, "depth": depth,
                                   "control": signatures[0], "candidate": signatures[1]})
    (out / "baseline_parity.json").write_text(json.dumps({
        "baseline_commit": "ec26c5e", "baseline_server_sha256": hashlib.sha256(baseline).hexdigest(),
        "candidate_source_inventory_sha256": source_before, "status": "PASS", "cases": parity,
    }, indent=2) + "\n", encoding="utf-8")
    print(f"Baseline parity: {len(parity)} cases PASS", flush=True)
    suite = unittest.defaultTestLoader.discover(str(ROOT / "tests"))
    discovered = suite.countTestCases()
    result, log, elapsed = execute_suite(suite, checkpoint=lease.checkpoint)
    (out / "full_suite.log").write_text(log, encoding="utf-8")
    unchanged = source_before == inventory_sha256(source_paths) and tests_before == inventory_sha256(test_inventory_paths())
    report = {"kind": "isolated-implementation-verification", "tests_discovered": discovered,
              "tests_run": result.testsRun, "failures": len(result.failures), "errors": len(result.errors),
              "skipped": len(result.skipped), "elapsed_seconds": elapsed, "baseline_parity_cases": len(parity),
              "source_inventory_sha256": source_before, "test_inventory_sha256": tests_before,
              "inventories_unchanged": unchanged, "protected_open_attempts": len(guard.triggered),
              "status": "PASS" if result.wasSuccessful() and unchanged and not guard.triggered else "FAIL"}
    (out / "full_suite.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report), flush=True)
    sys.exit(0 if report["status"] == "PASS" else 1)
